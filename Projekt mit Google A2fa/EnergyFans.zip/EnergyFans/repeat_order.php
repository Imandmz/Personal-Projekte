<?php
$orderId = $_POST['order_id'];
// Hole Artikel der alten Bestellung und kopiere sie in neue Bestellung
// Füge Rechnungsversand hinzu
header("Location: danke.php");

